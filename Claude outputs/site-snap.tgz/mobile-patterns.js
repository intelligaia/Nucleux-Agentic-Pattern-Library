/* ============================================================
   MOBILE PATTERNS — review surface for the phone layouts.
   Builds the pattern list from material-patterns.js, and drives two
   real device frames (Live Preview, Simulator) that load the pattern
   page in its device-frame mode (?embed=preview | sim). The frames
   report text-field focus; this page raises a keyboard and tells the
   page its height and the device's safe areas, so it reflows as a
   phone would. Nothing is scaled.
   ============================================================ */
(function () {
  var P = window.MaterialPatterns || {};
  /* Patterns made fully responsive so far. */
  var READY = { 'initial-cta': true };

  /* Viewports (CSS px). 402 × 874 — iPhone 18 Pro — is the target. */
  var DEVICES = [
    { w: 360, h: 780, label: '360', top: 24, bottom: 16, island: false },
    { w: 375, h: 812, label: '375', top: 50, bottom: 34, island: false },
    { w: 390, h: 844, label: '390', top: 47, bottom: 34, island: false },
    { w: 393, h: 852, label: '393', top: 59, bottom: 34, island: true },
    { w: 402, h: 874, label: '402', top: 62, bottom: 34, island: true, primary: true },
    { w: 430, h: 932, label: '430', top: 59, bottom: 34, island: true },
    { w: 440, h: 956, label: '440', top: 62, bottom: 34, island: true }
  ];
  var cur = DEVICES[4], orient = 'portrait';
  var q = new URLSearchParams(location.search);
  var id = P[q.get('id')] ? q.get('id') : 'initial-cta';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ── Left navigation: stage › category › pattern ── */
  function buildNav() {
    var order = [], groups = {};
    Object.keys(P).forEach(function (k) {
      var p = P[k];
      if (!groups[p.stage]) { groups[p.stage] = {}; order.push(p.stage); }
      (groups[p.stage][p.sub] = groups[p.stage][p.sub] || []).push(p);
    });
    var html = '';
    order.forEach(function (st) {
      html += '<p class="mpx-stage-h">' + esc(st) + '</p>';
      Object.keys(groups[st]).forEach(function (sub) {
        html += '<p class="mpx-sub-h">' + esc(sub) + '</p>';
        groups[st][sub].forEach(function (p) {
          html += '<a class="mpx-link" href="?id=' + encodeURIComponent(p.id) + '" data-id="' + esc(p.id) + '"' +
            (p.id === id ? ' aria-current="page"' : '') + '><span>' + esc(p.name) + '</span>' +
            (READY[p.id] ? '<span class="mpx-badge mpx-badge--ready">Mobile</span>' : '<span class="mpx-badge mpx-badge--soon">Soon</span>') + '</a>';
        });
      });
    });
    document.getElementById('mpx-list').innerHTML = html;
    document.getElementById('mpx-list').addEventListener('click', function (e) {
      var a = e.target.closest('.mpx-link'); if (!a) return;
      e.preventDefault(); select(a.getAttribute('data-id'), true);
    });
  }

  /* ── Header + frames for the selected pattern ── */
  function select(next, push) {
    id = next;
    var p = P[id];
    document.querySelectorAll('.mpx-link').forEach(function (a) {
      if (a.getAttribute('data-id') === id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    document.getElementById('mpx-crumb').textContent = p.stage + ' · ' + p.sub;
    document.getElementById('mpx-title').textContent = p.name;
    document.getElementById('mpx-lede').textContent = p.oneline || '';
    document.getElementById('mpx-desktop').href = 'material-pattern.html?id=' + encodeURIComponent(id);
    document.title = p.name + ' · Mobile patterns — Nucleux';
    var ready = !!READY[id];
    document.getElementById('mpx-device').hidden = !ready;
    document.getElementById('mpx-empty').hidden = ready;
    document.getElementById('mpx-parity').hidden = !PARITY[id];
    if (PARITY[id]) renderParity(PARITY[id]);
    if (ready) loadFrames();
    if (push) history.replaceState(null, '', '?id=' + encodeURIComponent(id));
  }

  /* ── Device toolbar ── */
  function buildBar() {
    var w = document.getElementById('mpx-widths');
    w.innerHTML = DEVICES.map(function (d, i) {
      return '<button type="button" role="radio" aria-checked="' + (d === cur) + '" data-i="' + i + '">' + d.label +
        (d.primary ? '<span class="mpx-star" aria-label="primary target">★</span>' : '') + '</button>';
    }).join('');
    w.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      cur = DEVICES[+b.getAttribute('data-i')];
      w.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-checked', x === b); });
      applySize();
    });
    var o = document.getElementById('mpx-orient');
    o.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      orient = b.getAttribute('data-orient');
      o.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-checked', x === b); });
      applySize();
    });
    /* Arrow keys move within each radio group. */
    [w, o].forEach(function (g) {
      g.addEventListener('keydown', function (e) {
        if (!/^Arrow(Left|Right)$/.test(e.key)) return;
        var bs = [].slice.call(g.querySelectorAll('button')), i = bs.indexOf(document.activeElement);
        if (i < 0) return;
        var n = bs[(i + (e.key === 'ArrowRight' ? 1 : bs.length - 1)) % bs.length];
        n.focus(); n.click(); e.preventDefault();
      });
    });
  }

  function dims() {
    var land = orient === 'landscape';
    return {
      w: land ? cur.h : cur.w, h: land ? cur.w : cur.h,
      top: land ? 0 : cur.top, bottom: land ? 21 : cur.bottom,
      kb: land ? 236 : (cur.w >= 430 ? 382 : 372)
    };
  }

  function applySize() {
    var d = dims();
    document.querySelectorAll('.mpx-phone').forEach(function (ph) {
      ph.style.setProperty('--w', d.w + 'px'); ph.style.setProperty('--h', d.h + 'px'); ph.style.setProperty('--kbh', d.kb + 'px');
      ph.setAttribute('data-orient', orient);
      ph.querySelector('.mpx-island').style.visibility = cur.island ? 'visible' : 'hidden';
    });
    document.getElementById('mpx-size').textContent = d.w + ' × ' + d.h + ' CSS px' + (cur.primary && orient === 'portrait' ? ' · iPhone 18 Pro' : '');
    hideKb(); iframes().forEach(sendSafe);
  }

  /* ── One phone, two views ──
     Both views are loaded once and kept alive; the switch only shows
     one, so moving between them never resets either. */
  var view = 'preview';
  var CAPS = {
    preview: 'States, Customize and Preview / Code — the pattern on its own.',
    sim: 'Planboard, a phone agentic app — the pattern inside a real workflow.'
  };
  function screen() { return document.getElementById('mpx-screen'); }
  function iframes() { return [].slice.call(screen().querySelectorAll('iframe')); }
  function active() { return screen().querySelector('iframe[data-mode="' + view + '"]'); }
  function sendSafe(ifr) {
    var d = dims();
    try { ifr.contentWindow.postMessage({ type: 'nx-safe', top: d.top, bottom: d.bottom }, '*'); } catch (e) {}
  }
  function showKb() {
    if (screen().getAttribute('data-kb') === 'true') return;
    screen().setAttribute('data-kb', 'true');
    try { active().contentWindow.postMessage({ type: 'nx-kb', h: dims().kb }, '*'); } catch (e) {}
  }
  function hideKb(blur) {
    screen().setAttribute('data-kb', 'false');
    iframes().forEach(function (ifr) {
      try {
        ifr.contentWindow.postMessage({ type: 'nx-kb', h: 0 }, '*');
        if (blur) { var a = ifr.contentDocument.activeElement; if (a && a.blur) a.blur(); }
      } catch (e) {}
    });
  }
  function setView(v) {
    view = v;
    hideKb(true);
    iframes().forEach(function (ifr) { ifr.hidden = ifr.getAttribute('data-mode') !== v; });
    document.querySelectorAll('.mpx-view button').forEach(function (b) {
      var on = b.getAttribute('data-view') === v;
      b.setAttribute('aria-selected', on); b.tabIndex = on ? 0 : -1;
    });
    screen().setAttribute('aria-labelledby', 'mpx-tab-' + v);
    document.getElementById('mpx-view-cap').textContent = CAPS[v];
  }
  function loadFrames() {
    iframes().forEach(function (ifr) {
      var src = 'material-pattern.html?id=' + encodeURIComponent(id) + '&embed=' + ifr.getAttribute('data-mode');
      if (ifr.getAttribute('src') !== src) ifr.setAttribute('src', src);
    });
    hideKb();
  }

  function drawKeys() {
    var rows = [[10, 0], [9, 0], [7, 2], [0, 3]], html = '';
    rows.forEach(function (r, i) {
      html += '<div class="mpx-kb__row">';
      if (i === 2) html += '<span class="w"></span>';
      if (i === 3) html += '<span class="w"></span><span class="w"></span><span class="s"></span><span class="w"></span>';
      for (var k = 0; k < r[0]; k++) html += '<span></span>';
      if (i === 2) html += '<span class="w"></span>';
      html += '</div>';
    });
    document.querySelectorAll('.mpx-kb__keys').forEach(function (k) { k.innerHTML = html; });
  }

  window.addEventListener('message', function (e) {
    var d = e.data || {};
    if (d.type !== 'nx-field-focus') return;
    var a = active(); if (!a || a.contentWindow !== e.source) return;
    if (d.on) showKb(); else hideKb();
  });
  document.addEventListener('click', function (e) {
    if (e.target.closest('.mpx-kb__done')) { hideKb(true); return; }
    var t = e.target.closest('.mpx-view button'); if (t) setView(t.getAttribute('data-view'));
  });
  /* Tabs: arrow keys move between the two views. */
  document.querySelector('.mpx-view').addEventListener('keydown', function (e) {
    if (!/^Arrow(Left|Right)$/.test(e.key)) return;
    var next = view === 'preview' ? 'sim' : 'preview';
    setView(next); document.getElementById('mpx-tab-' + next).focus(); e.preventDefault();
  });
  iframes().forEach(function (ifr) { ifr.addEventListener('load', function () { sendSafe(ifr); setTimeout(function () { sendSafe(ifr); }, 300); }); });

  /* ── Desktop → mobile parity, per pattern ── */
  var PARITY = {
    'initial-cta': [
      ['Text field', 'Inline in the composer row; grows to 8 lines', 'Own line above the controls; 16px type; starts 2 lines tall; grows to 6 lines, then scrolls inside', 'Tap to focus — keyboard rises, the composer rides above it'],
      ['Placeholder', 'One line, truncated', 'Wraps; never shrunk to fit', 'Disappears on the first keystroke; the field keeps its own label'],
      ['Add context (+)', 'Inline, left of the field; menu opens down', 'Inline, left of the control row; 44px target; menu opens upward at the composer’s width with 48px rows', 'One tap → Attach a file / Add a source'],
      ['Context chips', 'Inline before the field', 'Own row above the field', 'Tap a chip to remove it'],
      ['Model selection + effort', 'Inline chip “Balanced High”; flyout opens upward', 'Same chip, 44px tall, truncates before anything wraps; ≤ 390px shows the model only (effort stays in the flyout); flyout opens upward, right-aligned, within the screen', 'Tap chip → model list → effort'],
      ['Voice', 'Inline microphone', 'Inline microphone, 44px, right group', 'Tap → listening in the bar → Stop'],
      ['Send', 'Inline, right; fills when ready', 'Inline, right; 44px; same size disabled and active — only colour changes', 'Tap, or Return'],
      ['Supporting line', 'Centred above the composer', 'Left-aligned above the composer, low on the screen', '—'],
      ['Send-key hint', 'Under the composer on focus', 'Hidden: an on-screen keyboard has no key combination to learn; Send is the visible action', 'Send button'],
      ['States (5)', 'State menu in the toolbar', 'Same menu; the toolbar wraps to two rows', 'Tap → choose a state'],
      ['Customize', 'Side panel beside the preview', 'Bottom sheet over a scrim, all sections and controls', 'Tap Customize; close with ×, the scrim or Escape'],
      ['Preview | Code', 'Segmented toggle', 'Same toggle; code wraps inside the frame, no page scroll', 'Tap'],
      ['Hand-over to conversation', 'Same composer moves to the dock', 'Same composer moves to the bottom, above the home indicator, at working size', 'Automatic on first send'],
      ['Simulator navigation', 'Left sidebar', 'App bar: menu button opens the same list as a drop-down sheet (48px rows); New task is the + in the app bar', 'Tap ☰ / +'],
      ['Keyboard', 'n/a', 'Composer stays above the keyboard; the empty-state space gives way first', 'visualViewport on a phone; reported by the frame here'],
      ['Safe areas', 'n/a', 'env(safe-area-inset-*) through --sa-t / --sa-b; nothing hard-coded for the island or the home indicator', '—']
    ]
  };
  function renderParity(rows) {
    document.getElementById('mpx-parity-rows').innerHTML = rows.map(function (r) {
      return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td><td>' + esc(r[3]) + '</td></tr>';
    }).join('');
  }

  buildNav(); buildBar(); drawKeys(); applySize(); select(id, false);
})();
